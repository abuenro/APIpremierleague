#Plantilla para el curso de Sistemas de Información 2019-2

###BD mongo mongodb://<dbuser>:<dbpassword>@ds055680.mlab.com:55680/alumnos


**API URLs**

* Todos los usuarios
  * http://localhost:3000/api/users
* Un usuario by ids
  * http://localhost:3000/api/users/:id
