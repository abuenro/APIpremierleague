var express = require('express');
var mongoosee = require('mongoosee');
var bodyParser = require('body-parser');
var router = express.Router();

var app = express();

var db = mongoosee.db('mongodb://@localhost:27017/testdatabase', {safe:true});
var id = mongoosee.helper.toObjectID;

var allowMethods = function(req, res, next) {
  res.header('Access-control-Allow-Mehtods','get','post','put','delete','patch')

var allowCrossTokenHeader = function(req, res, next) {
  res.header('Access-control-Allow-Headers' , 'token');
};

var auth = function(req, res, next) {
  if(req.headers.token === 'necesito10') {
    return next();
  } else {
    return(new Error('no autorizado'));
  }
}

app.listen(27017, function(){
    console.log('servidor escuchando en el puerto 27017');
});

app.param('coleccion', function(req, res, next, coleccion) {
    req.collection = db.collection(coleccion);
});


app.use(bodyParser.urlencode({extended: true}));
app.use(bodyParser.json());
app.use(allowMethods);
app.use(allowCrossTokenHeader);


app.post('/api/:coleccion', auth,  function(req, res, next){
  req.collection.insert(req.body, {}, function(e, result){
    if(e) return next(e);
    res.send(result);
  });
});


app.get('/api/:coleccion', auth, function(req, res, next){
  req.coleccion.find({}, {limit: 10, sort: [['_id', -1]]}).toArray(function(e, results){
    if(e) return next(e);
    res.send(result);
  });
});

app.get('/api/:coleccion/:id', auth, function(req, res, next){
  req.collection.findOne({_id: id(req.parans.id)}, function(e, results){
    if(e) return next(e);
    res.send(result);
  });
});

app.put('/api/:coleccion/:id', auth, function(req, res, next){
  req.collection.update({_id: id(req.params.id)}, {$set:req.body}, {safe: true, multi: false},
  function(e, results){
    if(e) return next(e);
    res.send((result === 1) ? {resultado: 'ok'} : {resultado:'ko'});
  });
});

app.delete('/api/:coleccion/:id', auth, function(){
  req.collection.remove({_id: id(req.params.id)}, function(e, results){
    if(e) return next(e);
    res.send((result === 1) ? {resultado: 'ok'} : {resultado:'ko'});
  });
});

